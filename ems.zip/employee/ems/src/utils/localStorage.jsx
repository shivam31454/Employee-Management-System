const employees = [
    {
      "id": 1,
      "email": "employee1@example.com",
      "password": "123",
      "tasks": [
        {
          "title": "Complete project report",
          "description": "Prepare and submit the final project report.",
          "date": "2025-03-30",
          "category": "Documentation",
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false
        },
        {
          "title": "Code Review",
          "description": "Review code for the new feature implementation.",
          "date": "2025-03-28",
          "category": "Development",
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false
        }
      ]
    },
    {
      "id": 2,
      "email": "employee2@example.com",
      "password": "123",
      "tasks": [
        {
          "title": "Design UI Mockups",
          "description": "Create UI mockups for the mobile application.",
          "date": "2025-04-01",
          "category": "Design",
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false
        },
        {
          "title": "Fix UI Bugs",
          "description": "Resolve reported UI issues from the testing phase.",
          "date": "2025-03-27",
          "category": "Development",
          "active": false,
          "newTask": false,
          "completed": false,
          "failed": true
        }
      ]
    },
    {
      "id": 3,
      "email": "employee3@example.com",
      "password": "123",
      "tasks": [
        {
          "title": "Server Maintenance",
          "description": "Perform routine server maintenance.",
          "date": "2025-03-29",
          "category": "IT",
          "active": true,
          "newTask": false,
          "completed": false,
          "failed": false
        },
        {
          "title": "Database Backup",
          "description": "Create a backup of the company database.",
          "date": "2025-03-28",
          "category": "Database",
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false
        }
      ]
    },
    {
      "id": 4,
      "email": "employee4@example.com",
      "password": "123",
      "tasks": [
        {
          "title": "Client Meeting",
          "description": "Attend a meeting with a potential client.",
          "date": "2025-03-31",
          "category": "Business",
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false
        },
        {
          "title": "Market Research",
          "description": "Analyze competitor strategies.",
          "date": "2025-03-26",
          "category": "Marketing",
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false
        }
      ]
    },
    {
      "id": 5,
      "email": "employee5@example.com",
      "password": "123",
      "tasks": [
        {
          "title": "Write Blog Post",
          "description": "Create a blog post about the latest tech trends.",
          "date": "2025-04-02",
          "category": "Content",
          "active": true,
          "newTask": true,
          "completed": false,
          "failed": false
        },
        {
          "title": "Social Media Campaign",
          "description": "Launch a new marketing campaign on social media.",
          "date": "2025-03-28",
          "category": "Marketing",
          "active": false,
          "newTask": false,
          "completed": true,
          "failed": false
        }
      ]
    }
  ];
  
  const admin = [
    {
      "id": 1,
      "email": "admin@example.com",
      "password": "123"
    }
  ];

  export const setLocalStorage=()=>{
    localStorage.setItem('employees',JSON.stringify(employees))
    localStorage.setItem('admin',JSON.stringify(admin))

  }
  
  export const getLocalStorage=()=>{
    const employees=localStorage.getItem('employees');
    const admin=localStorage.getItem('admin');
    return{employees,admin};
  }